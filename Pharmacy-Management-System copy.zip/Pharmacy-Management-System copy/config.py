SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:JaviaD@13@localhost/pharmacy_management_system'


<?php
session_start();
include_once('connect_db.php');

if (isset($_SESSION['username'])) {
    $id = $_SESSION['pharmacist_id'] ?? null;
    $user = $_SESSION['username'];
} else {
    header("Location: http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/index.php");
    exit();
}

if (isset($_GET['prescription_id'])) {
    $prescription_id = $_GET['prescription_id'];

    // Prepare the SQL query to delete the prescription
    $stmt = $conn->prepare("DELETE FROM prescription WHERE prescription_id = ?");
    $stmt->bind_param("i", $prescription_id);

    if ($stmt->execute()) {
        header("Location: http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/prescription.php");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }
    $stmt->close();
} else {
    echo "No prescription ID provided.";
}

$conn->close();
?>

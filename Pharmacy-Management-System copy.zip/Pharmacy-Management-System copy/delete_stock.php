<?php
session_start();
include_once('connect_db.php');

// Check if the user is logged in
if (isset($_SESSION['username'])) {
    $id = $_SESSION['admin_id'];
    $user = $_SESSION['username'];
} else {
    header("Location: http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/index.php");
    exit();
}

// Ensure that 'stock_id' is retrieved from the GET parameters
if (isset($_GET['stock_id'])) {
    $stock_id = $_GET['stock_id'];

    // Prepare and execute the delete query
    $sql = "DELETE FROM stock WHERE stock_id='$stock_id'";
    if (mysqli_query($conn, $sql)) {
        // Redirect to the stock page after deletion
        header("Location: http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/stock.php");
        exit();
    } else {
        // Handle error if query fails
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    // If 'stock_id' is not set, redirect to the stock page
    header("Location: http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/stock.php");
    exit();
}
?>

<?php
session_start();
include_once('connect_db.php');

if (isset($_SESSION['username'])) {
    $id = $_SESSION['admin_id'];
    $user = $_SESSION['username'];
} else {
    header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
    exit();
}

// Ensure that the `pharmacist_id` parameter is provided
if (isset($_GET['manager_id'])) {
    $id = $_GET['manager_id'];

    // Prepare and execute the delete query
    $sql = "DELETE FROM manager WHERE manager_id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("i", $id); // "i" specifies the type is integer
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            // Successfully deleted
            header("location:admin_manager.php");
        } else {
            // Deletion failed or no rows affected
            echo "Failed to delete or no such record found.";
        }

        $stmt->close();
    } else {
        // Error preparing the statement
        echo "Error preparing statement: " . $conn->error;
    }
} else {
    echo "Manager ID is not specified.";
}

$conn->close();
?>

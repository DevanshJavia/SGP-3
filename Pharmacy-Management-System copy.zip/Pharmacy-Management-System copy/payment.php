<?php
session_start();
include_once('connect_db.php');

// Check if user is logged in
if (isset($_SESSION['username'])) {
    $id = $_SESSION['cashier_id'];
    $user = $_SESSION['username'];
} else {
    header("Location: http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
    exit();
}

$message = '';
$message1 = '';

if (isset($_POST['submit'])) {
    $invoice_no = $_POST['invoice_no'];
    $cname = $_POST['customer_name'];
    $ptype = $_POST['payment_type'];
    $total = $_POST['total_ammount'];

    // Prepare and execute the query to check if the invoice_no exists
    $stmt = $conn->prepare("SELECT * FROM invoice WHERE invoice_no = ?");
    $stmt->bind_param("s", $invoice_no);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Invoice exists, proceed to insert into payment_details
        $stmt = $conn->prepare("INSERT INTO payment_details (invoice_no, customer_name, payment_type, total_ammount) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $invoice_no, $cname, $ptype, $total);

        if ($stmt->execute()) {
            header("Location: http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/payment.php");
            exit();
        } else {
            $message1 = "<font color='red'>Registration Failed, Try again</font>";
        }
        
        $stmt->close();
    } else {
        $message1 = "<font color='red'>Invoice No does not exist</font>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo htmlspecialchars($user); ?> - Pharmacy Management System</title>
<link rel="stylesheet" type="text/css" href="style/mystyle.css">
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen" /> 
<link rel="stylesheet" href="style/table.css" type="text/css" media="screen" /> 
<script src="js/function.js" type="text/javascript"></script>
<style>#left-column {height: 477px;} #main {height: 477px;}</style>
</head>
<body>
<div id="content">
<div id="header">
<h1><a href="#"><img src="images/main_logo.jpg" alt="Logo"></a> Pharmacy Management System</h1></div>
<div id="left_column">
<div id="button">
<ul>
    <li><a href="manager.php">Dashboard</a></li>
    <li><a href="view.php">Process Payments</a></li>
    <li><a href="logout.php">Logout</a></li>
</ul>  
</div>
</div>
<div id="main">
<div id="tabbed_box" class="tabbed_box">  
    <h4>Manage Payments</h4> 
<hr/>  
    <div class="tabbed_area">  
        <ul class="tabs">  
            <li><a href="javascript:tabSwitch('tab_1', 'content_1');" id="tab_1" class="active">View Payments</a></li>  
            <li><a href="javascript:tabSwitch('tab_2', 'content_2');" id="tab_2">Add New Payment Details</a></li>  
        </ul>  
          
        <div id="content_1" class="content">  
         <?php echo $message; ?>
         <?php echo $message1; ?>
      
        <?php
        // View
        // Displays all data from 'payment_details' table

        // Get results from database
        $result = $conn->query("SELECT * FROM payment_details");

        if ($result->num_rows > 0) {
            // Display data in table
            echo "<table border='1' cellpadding='3'>";
            echo "<tr><th>payment_id</th><th>invoice_no</th><th>customer_name</th><th>payment_type</th><th>total_ammount</th><th>Delete</th></tr>";

            // Loop through results of database query, displaying them in the table
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo '<td>' . htmlspecialchars($row['payment_id']) . '</td>';               
                echo '<td>' . htmlspecialchars($row['invoice_no']) . '</td>';
                echo '<td>' . htmlspecialchars($row['customer_name']) . '</td>';
                echo '<td>' . htmlspecialchars($row['payment_type']) . '</td>';
                echo '<td>' . htmlspecialchars($row['total_ammount']) . '</td>';?>
                <td><a href="delete_payment.php?payment_id=<?php echo htmlspecialchars($row['payment_id']) ?>"><img src="images/delete-icon.jpg" width="24" height="24" border="0" alt="Delete"/></a></td>
                <?php
            } 
            // Close table
            echo "</table>";
        } else {
            echo "No payments found.";
        }
        ?>

        </div>  
        <div id="content_2" class="content">  
         <!-- Add Payment -->
         <?php echo $message; ?>
         <?php echo $message1; ?>
         <form name="myform" onsubmit="return validateForm(this);" action="payment.php" method="post" >
            <table width="420" height="106" border="0">    
                <tr><td align="center"><input name="invoice_no" type="text" style="width:170px" placeholder="Invoice No" required="required" id="invoice_no" /></td></tr>
                <tr><td align="center"><input name="customer_name" type="text" style="width:170px" placeholder="Customer Name" required="required" id="customer_name"/></td></tr>
                <tr><td align="center"><input name="payment_type" type="text" style="width:170px" placeholder="Payment Type" required="required" id="payment_type" /></td></tr>
                <tr><td align="center"><input name="total_ammount" type="text" style="width:170px" placeholder="Total" required="required" id="total_ammount" /></td></tr>  
                <tr><td align="center"><input name="submit" type="submit" value="Submit" id="submit"/></td></tr>
            </table>
        </form>
        </div>  
    </div>  
</div>
</div>
<div id="footer" align="Center">SVMS was Developed By Devansh and Diya</div>
</div>
</body>
</html>

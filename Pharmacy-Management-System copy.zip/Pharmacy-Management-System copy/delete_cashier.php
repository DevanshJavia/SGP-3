<?php
session_start();
include_once('connect_db.php');

if (isset($_SESSION['username'])) {
    $id = $_SESSION['admin_id'];
    $username = $_SESSION['username'];
} else {
    header("Location: http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
    exit();
}

// Make sure to properly sanitize and validate the input
if (isset($_GET['cashier_id'])) {
    $id = $_GET['cashier_id'];

    // Prepare the SQL query
    $sql = "DELETE FROM cashier WHERE cashier_id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("i", $id); // 'i' specifies the type of the parameter (integer)
        if ($stmt->execute()) {
            header("Location: admin_cashier.php");
        } else {
            echo "<font color=red>Error executing query: " . $stmt->error . "</font>";
        }
        $stmt->close();
    } else {
        echo "<font color=red>Error preparing statement: " . $conn->error . "</font>";
    }
} else {
    echo "<font color=red>No ID provided</font>";
}

$conn->close();
?>

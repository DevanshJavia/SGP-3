<?php
error_reporting(E_ERROR | E_PARSE);

// Database connection parameters
$host = 'localhost'; // Replace with your host
$username = 'root'; // Replace with your MySQL username
$password = 'Itsdiya772004!'; // Replace with your MySQL password
$database = 'pms'; // Replace with your database name

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
<?php
session_start();
include_once('connect_db.php');

// Check if user is logged in
if (isset($_SESSION['username'])) {
    $id = $_SESSION['manager_id'];
    $user = $_SESSION['username'];
} else {
    header("Location: http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
    exit();
}

// Initialize message variables
$message = '';
$message1 = '';

?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo htmlspecialchars($user); ?> - Pharmacy Management System</title>
<link rel="stylesheet" type="text/css" href="style/mystyle.css">
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen" /> 
<link rel="stylesheet" href="style/table.css" type="text/css" media="screen" /> 
<script src="js/function.js" type="text/javascript"></script>
<style>#left-column {height: 477px;} #main {height: 477px;}</style>
</head>
<body>
<div id="content">
<div id="header">
<h1><a href="#"><img src="images/main_logo.jpg" alt="Logo"></a> Pharmacy Management System</h1></div>
<div id="left_column">
<div id="button">
<ul>
    <li><a href="manager.php">Dashboard</a></li>
    <li><a href="view.php">View Users</a></li>
    <li><a href="view_prescription.php">View Prescription</a></li>
    <li><a href="invoice.php">Manage Invoices</a></li>
    <li><a href="stock.php">Manage Stock</a></li>
    <li><a href="logout.php">Logout</a></li>
</ul>  
</div>
</div>
<div id="main">
<div id="tabbed_box" class="tabbed_box">  
    <h4>Manage Users</h4> 
<hr/>  
    <div class="tabbed_area">  
        <ul class="tabs">  
            <li><a href="javascript:tabSwitch('tab_1', 'content_1');" id="tab_1" class="active">View Users</a></li>  
            <li><a href="javascript:tabSwitch('tab_2', 'content_2');" id="tab_2">Add New User</a></li>  
        </ul>  
          
        <div id="content_1" class="content">  
         <?php echo $message; ?>
         <?php echo $message1; ?>

        <?php
        // View
        // Displays all data from 'user_accounts' table

        // Prepare and execute the query
        $stmt = $conn->prepare("SELECT * FROM user_accounts");
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Display data in table
            echo "<table border='1' cellpadding='3'>";
            echo "<tr><th>user_id</th><th>username</th><th>role</th><th>Delete</th></tr>";

            // Loop through results of database query, displaying them in the table
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo '<td>' . htmlspecialchars($row['user_id']) . '</td>';               
                echo '<td>' . htmlspecialchars($row['username']) . '</td>';
                echo '<td>' . htmlspecialchars($row['role']) . '</td>'; ?>
                <td><a href="delete_user.php?user_id=<?php echo htmlspecialchars($row['user_id']) ?>"><img src="images/delete-icon.jpg" width="24" height="24" border="0" alt="Delete"/></a></td>
                <?php
            } 
            // Close table
            echo "</table>";
        } else {
            echo "No users found.";
        }
        ?>

        </div>  
        <div id="content_2" class="content">  
         <!-- Add User -->
         <?php echo $message; ?>
         <?php echo $message1; ?>
         <form name="myform" onsubmit="return validateForm(this);" action="add_user.php" method="post" >
            <table width="420" height="106" border="0">    
                <tr><td align="center"><input name="username" type="text" style="width:170px" placeholder="Username" required="required" id="username" /></td></tr>
                <tr><td align="center"><input name="role" type="text" style="width:170px" placeholder="Role" required="required" id="role" /></td></tr>
                <tr><td align="center"><input name="submit" type="submit" value="Submit" id="submit"/></td></tr>
            </table>
        </form>
        </div>  
    </div>  
</div>
</div>
<div id="footer" align="Center">SVMS was Developed By Devansh and Diya</div>
</div>
</body>
</html>

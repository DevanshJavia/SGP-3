<?php
session_start();
include_once('connect_db.php');

if (isset($_SESSION['username'])) {
    $user = $_SESSION['username'];
    $id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : null;
} else {
    header("Location: http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/index.php");
    exit();
}

$message = '';
$message1 = '';

if (isset($_POST['submit'])) {
    $did = $_POST['drug_id'];
    $dname = $_POST['drug_name'];
    $set = $_POST['strength'];
    $dose = $_POST['dose'];
    $qua = $_POST['quantity'];

    // Check if the column names match the table schema
    $stmt = $conn->prepare("INSERT INTO stock (stock_id, drug_name, strength, dose, quantity) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssi", $did, $dname, $set, $dose, $qua);

    if ($stmt->execute()) {
        $message = "<font color='green'>Stock added successfully</font>";
    } else {
        $message1 = "<font color='red'>Failed to add stock, try again</font>";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo htmlspecialchars($user); ?> - Pharmacy Management System</title>
<link rel="stylesheet" type="text/css" href="style/mystyle.css">
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen" /> 
<link rel="stylesheet" href="style/table.css" type="text/css" media="screen" /> 
<script src="js/function.js" type="text/javascript"></script>
<style>
    #left-column { height: 477px; }
    #main { height: 477px; }
</style>
</head>
<body>
<div id="content">
    <div id="header">
        <h1><a href="#"><img src="images/main_logo.jpg"></a> Pharmacy Management System</h1>
    </div>
    <div id="left_column">
        <div id="button">
            <ul>
                <li><a href="admin.php">Dashboard</a></li>
                <li><a href="stock.php">Stock</a></li>
                <li><a href="prescription.php">Prescription</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
    <div id="main">
        <div id="tabbed_box" class="tabbed_box">
            <h4>Manage Stock</h4>
            <hr/>
            <div class="tabbed_area">
                <ul class="tabs">
                    <li><a href="javascript:tabSwitch('tab_1', 'content_1');" id="tab_1" class="active">View Stock</a></li>
                    <li><a href="javascript:tabSwitch('tab_2', 'content_2');" id="tab_2">Add Stock Details</a></li>
                </ul>

                <div id="content_1" class="content">
                    <?php echo $message; echo $message1; ?>
                    <?php
                    $result = mysqli_query($conn, "SELECT * FROM stock") or die(mysqli_error($conn));
                    echo "<table border='1' cellpadding='3'>";
                    echo "<tr><th>ID</th><th>Drug Name</th><th>Strength</th><th>Dose</th><th>Quantity</th><th>Delete</th></tr>";
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo '<td>' . htmlspecialchars($row['stock_id']) . '</td>';
                        echo '<td>' . htmlspecialchars($row['drug_name']) . '</td>';
                        echo '<td>' . htmlspecialchars(isset($row['strength']) ? $row['strength'] : 'N/A') . '</td>';
                        echo '<td>' . htmlspecialchars(isset($row['dose']) ? $row['dose'] : 'N/A') . '</td>';
                        echo '<td>' . htmlspecialchars($row['quantity']) . '</td>';
                        echo '<td><a href="delete_stock.php?stock_id=' . htmlspecialchars($row['stock_id']) . '"><img src="images/delete-icon.jpg" width="24" height="24" border="0" /></a></td>';
                        echo "</tr>";
                    }
                    echo "</table>";
                    ?>
                </div>

                <div id="content_2" class="content">
                    <?php echo $message; echo $message1; ?>
                    <form name="myform" onsubmit="return validateForm(this);" action="stock.php" method="post">
                        <table width="420" height="106" border="0">
                            <tr><td align="center"><input name="drug_id" type="text" style="width:170px" placeholder="Drug ID" required="required" id="drug_id" /></td></tr>
                            <tr><td align="center"><input name="drug_name" type="text" style="width:170px" placeholder="Drug Name" required="required" id="drug_name" /></td></tr>
                            <tr><td align="center"><input name="strength" type="text" style="width:170px" placeholder="Strength" required="required" id="strength"/></td></tr>
                            <tr><td align="center"><input name="dose" type="text" style="width:170px" placeholder="Dose" required="required" id="dose" /></td></tr>
                            <tr><td align="center"><input name="quantity" type="text" style="width:170px" placeholder="Quantity" required="required" id="quantity" /></td></tr>
                            <tr><td align="center"><input name="submit" type="submit" value="Submit" id="submit"/></td></tr>
                        </table>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <div id="footer" align="center">SVMS was Developed By Devansh and Diya</div>
</div>
</body>
</html>

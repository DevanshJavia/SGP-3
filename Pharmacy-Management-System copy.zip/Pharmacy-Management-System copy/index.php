<?php
include_once 'connect_db.php';

// Initialize variables
$message = '';

// Handle form submission
if(isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $position = $_POST['position'];
    
    switch($position) {
        case 'Admin':
            $query = "SELECT admin_id, username FROM admin WHERE username='$username' AND password='$password'";
            $result = $conn->query($query);
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_array(MYSQLI_NUM);
                session_start();
                $_SESSION['admin_id'] = $row[0];
                $_SESSION['username'] = $row[1];
                header("location: admin.php");
                exit;
            } else {
                $message = "<font color='red'>Invalid login. Try Again.</font>";
            }
            break;
        
        case 'Pharmacist':
            $query = "SELECT pharmacist_id, first_name, last_name, staff_id, username FROM pharmacist WHERE username='$username' AND password='$password'";
            $result = $conn->query($query);
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_array(MYSQLI_NUM);
                session_start();
                $_SESSION['pharmacist_id'] = $row[0];
                $_SESSION['first_name'] = $row[1];
                $_SESSION['last_name'] = $row[2];
                $_SESSION['staff_id'] = $row[3];
                $_SESSION['username'] = $row[4];
                header("location: pharmacist.php");
                exit;
            } else {
                $message = "<font color='red'>Invalid login. Try Again.</font>";
            }
            break;
        
        case 'Cashier':
            $query = "SELECT cashier_id, first_name, last_name, staff_id, username FROM cashier WHERE username='$username' AND password='$password'";
            $result = $conn->query($query);
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_array(MYSQLI_NUM);
                session_start();
                $_SESSION['cashier_id'] = $row[0];
                $_SESSION['first_name'] = $row[1];
                $_SESSION['last_name'] = $row[2];
                $_SESSION['staff_id'] = $row[3];
                $_SESSION['username'] = $row[4];
                header("location: cashier.php");
                exit;
            } else {
                $message = "<font color='red'>Invalid login. Try Again.</font>";
            }
            break;
        
        case 'Manager':
            $query = "SELECT manager_id, first_name, last_name, staff_id, username FROM manager WHERE username='$username' AND password='$password'";
            $result = $conn->query($query);
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_array(MYSQLI_NUM);
                session_start();
                $_SESSION['manager_id'] = $row[0];
                $_SESSION['first_name'] = $row[1];
                $_SESSION['last_name'] = $row[2];
                $_SESSION['staff_id'] = $row[3];
                $_SESSION['username'] = $row[4];
                header("location: manager.php");
                exit;
            } else {
                $message = "<font color='red'>Invalid login. Try Again.</font>";
            }
            break;
        
        default:
            $message = "<font color='red'>Please select a position.</font>";
            break;
    }
}

// HTML structure and form
echo <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pharmacy Management System</title>
    <!-- Include your CSS files here -->
    <link rel="stylesheet" href="home_page/css/modal1.css">
    <link rel="stylesheet" href="home_page/css/home.css">
    <link rel="stylesheet" href="home_page/css/modal.css">
    <link rel="stylesheet" href="home_page/css/responsiveslides.css">
    <script src="home_page/js/jquery.min.js"></script>
    <script src="home_page/js/responsiveslides.min.js"></script>
    <script>
        $(function () {
            $("#slider1").responsiveSlides({
                width: 600,
                speed: 600
            });
        });
    </script>
</head>
<body>
    <div id="header">
        <img class="i" src="home_page/images/417MD1XvpVL._AC_UL600_SR600,600_.jpg" alt="Logo">
        <h1 class="head">SRI VARI Medical Store</h1>
        <h3><marquee>"It is easy to get a thousand prescriptions, but hard to get one single remedy"</marquee></h3>
    </div>
    <div id="center">
        <div class="image-slider">
            <!-- Slideshow Images -->
            <ul class="rslides" id="slider1">
                <li><img src="home_page/images/6.jpg" alt=""></li>
                <li><img src="home_page/images/7.jpg" alt=""></li>
                <li><img src="home_page/images/8.jpg" alt=""></li>
                <li><img src="home_page/images/9.jpg" alt=""></li>
                <li><img src="home_page/images/10.jpg" alt=""></li>
            </ul>
        </div>
    </div>
    <div id="vertical">
        <section class="container">
            <div class="login">
                <h1>Login here</h1>
                $message
                <form method="post" action="">
                    <p><input type="text" name="username" value="" placeholder="Username"></p>
                    <p><input type="password" name="password" value="" placeholder="Password"></p>
                    <p><select name="position">
                        <option>--Select position--</option>
                        <option>Admin</option>
                        <option>Pharmacist</option>
                        <option>Cashier</option>
                        <option>Manager</option>
                    </select></p>
                    <p class="submit"><input type="submit" name="submit" value="Login"></p>
                </form>
            </div>
        </section>
    </div>
    <div id="btm">
        <ul><p><a class="foot" href="about/about.html">ABOUT US</a></p></ul>
        <div id="imga" ><img class="im" src="home_page/images/clogo.jpg.avif" href="../home.php"></div>
        <div id="down2">SVMS was Developed By Devansh and Diya</div>
    </div>
</body>
</html>
HTML;
?>

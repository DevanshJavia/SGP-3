<?php
session_start();
include_once('connect_db.php');

$message1 = ''; // Initialize message1

if (isset($_SESSION['username'])) {
    $id = $_SESSION['admin_id'];
    $username = $_SESSION['username'];
} else {
    header("Location: http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
    exit();
}

// Fetch the data for the given cashier username
if (isset($_GET['username'])) {
    $username = $_GET['username'];

    // Prepare the SQL query to get cashier data
    $sql = "SELECT * FROM cashier WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $cashier = $result->fetch_assoc();
        } else {
            $message1 = "<font color=red>No data found for the username</font>";
        }
    } else {
        $message1 = "<font color=red>Error executing query: " . $stmt->error . "</font>";
    }
    $stmt->close();
}

// Update cashier information
if (isset($_POST['update_pr'])) {
    $fname = $_POST['first_name'];
    $lname = $_POST['last_name'];
    $sid = $_POST['staff_id'];
    $postal = $_POST['postal_address'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $pas = $_POST['password'];

    // Prepare the SQL query to update cashier data
    $sql = "UPDATE cashier SET first_name = ?, last_name = ?, staff_id = ?, postal_address = ?, phone = ?, email = ?, password = ? WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $fname, $lname, $sid, $postal, $phone, $email, $pas, $username);

    if ($stmt->execute()) {
        header("Location: admin_cashier.php");
    } else {
        $message1 = "<font color=red>Update Failed, Try again</font>";
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
<title>Update Cashier</title>
<link rel="stylesheet" type="text/css" href="style/mystyle.css">
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen" /> 
<link rel="stylesheet" href="style/table.css" type="text/css" media="screen" />
</head>
<body>
<div id="content">
    <div id="header">
        <h1><a href="#"><img src="images/main_logo.jpg"></a> Pharmacy Management System</h1>
    </div>
    <div id="left_column">
        <div id="button">
            <ul>
                <li><a href="admin.php">Dashboard</a></li>
                <li><a href="admin_pharmacist.php">Pharmacist</a></li>
                <li><a href="admin_manager.php">Manager</a></li>
                <li><a href="admin_cashier.php">Cashier</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>    
        </div>
    </div>
    <div id="main">
        <div id="tabbed_box" class="tabbed_box">  
            <h4>Update Cashier</h4> 
            <hr/>  
            <div class="tabbed_area">  
                <div id="content_1" class="content">
                    <?php echo $message1; ?>
                    <form name="form1" action="update_cashier.php" method="post">
                        <table width="220" height="300" border="0">    
                            <tr><td align="center"><input name="first_name" type="text" style="width:170px" value="<?php echo $cashier['first_name']; ?>" placeholder="First Name" required="required" id="first_name" /></td></tr>
                            <tr><td align="center"><input name="last_name" type="text" style="width:170px" value="<?php echo $cashier['last_name']; ?>" placeholder="Last Name" required="required" id="last_name" /></td></tr>
                            <tr><td align="center"><input name="staff_id" type="text" style="width:170px" value="<?php echo $cashier['staff_id']; ?>" placeholder="Staff ID" required="required" id="staff_id"/></td></tr>  
                            <tr><td align="center"><input name="postal_address" type="text" style="width:170px" value="<?php echo $cashier['postal_address']; ?>" placeholder="Address" required="required" id="postal_address" /></td></tr>  
                            <tr><td align="center"><input name="phone" type="text" style="width:170px" value="<?php echo $cashier['phone']; ?>" placeholder="Phone"  required="required" id="phone" /></td></tr>  
                            <tr><td align="center"><input name="email" type="email" style="width:170px" value="<?php echo $cashier['email']; ?>" placeholder="Email" required="required" id="email" /></td></tr>   
                            <tr><td align="center"><input name="username" type="text" style="width:170px" value="<?php echo $cashier['username']; ?>" placeholder="Username" required="required" id="username" /></td></tr>
                            <tr><td align="center"><input name="password" type="password" style="width:170px" value="<?php echo $cashier['password']; ?>" placeholder="Password" required="required" id="password"/></td></tr>
                            <tr><td align="right"><input name="update_pr" type="submit" value="Update"/></td></tr>
                        </table>
                    </form>
                </div>  
            </div>  
        </div>
    </div>
    <div id="footer" align="Center">SVMS was Developed By Devansh and Diya</div>
</div>
</body>
</html>
